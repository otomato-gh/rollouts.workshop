# Install Kiali

```bash
export KIALI_IMAGE_VERSION=v0.20
bash <(curl -L https://git.io/getLatestKialiOperator)
```

## Let's Look at Kiali UI

```bash
