layout: true

<div class="my-header"><img src="images/otologo.png" style="height: 30px;"/></div>
<div class="my-footer"><span>&copy; 2011 - 2015 My Company, Inc.</span></div>